Cierre Diario — Transportes Tango

Archivos:
- index.html: mini app
- manifest.webmanifest: permite instalarla como app en el celular
- service-worker.js: permite uso offline una vez publicada/abierta desde HTTPS

Funciones:
- Control separado para Jorge y Camila
- Bitácora, cartera, redes, seguimiento y alarmas
- Meta semanal automática de 20 contactos
- Guarda cierres en el dispositivo
- Genera texto listo para copiar/compartir en el chat de Transportes
- Muestra últimos 7 cierres

Para usarla como app instalada en Android/iPhone debe publicarse en un sitio HTTPS,
por ejemplo GitHub Pages. Una vez publicada, se abre en Chrome/Safari y se usa
"Agregar a pantalla de inicio" / "Instalar app".
